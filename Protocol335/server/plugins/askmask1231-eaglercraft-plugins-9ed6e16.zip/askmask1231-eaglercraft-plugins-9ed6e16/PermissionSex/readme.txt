An actual good permissions plugin for your server. if you hate bitchfilter and permissionsbukkit. have this ago. this plugin also supports ranks which is very cool.
