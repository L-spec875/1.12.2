## DupePatch

Patches some of the most common 1.5.2 dupe glitches players may abuse

**Download DupePatch here: [https://github.com/darverdevs/DupePatch/releases](https://github.com/darverdevs/DupePatch/releases)**